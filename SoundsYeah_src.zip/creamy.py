import os
import sys
import random
import pygame
import threading
import ctypes
import json
import customtkinter as ctk
from pynput import keyboard, mouse
from PIL import Image, ImageDraw
import pystray
from pystray import MenuItem as item
import tkinter as tk
import locale

# --- ÚTVONAL KEZELÉS ---
def resource_path(relative_path):
    try: base_path = sys._MEIPASS
    except Exception: base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

if getattr(sys, 'frozen', False):
    base_dir = os.path.dirname(sys.executable)
else:
    base_dir = os.path.dirname(os.path.abspath(__file__))

CONFIG_FILE = os.path.join(base_dir, "config.json")

try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('amongaming.soundsyeah.v202')
except: pass

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()

class CreamyApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("SoundsYeah")
        self.icon_path = resource_path("icon.png")
        
        try: lang = locale.getdefaultlocale()[0]
        except: lang = "en"
        self.is_hu = lang and "hu" in lang.lower()

        self.withdraw() 
        self.overrideredirect(True)
        self.geometry("520x620")
        self.attributes("-topmost", True)
        self.config(bg='#242424') 
        self.attributes("-transparentcolor", "#242424")

        self.col_path = resource_path('keys')
        self.m_idx, self.k_idx = 0, 0
        self.initial_m_idx, self.initial_k_idx = 0, 0 
        self.current_volume = 0.5
        self.pressed_keys = set()
        
        # Ez a változó figyeli, hogy szabad-e már zenélni
        self.sounds_enabled = False 

        self.folders = self.get_sound_packs()
        self.setup_ui()
        self.load_settings() 
        self.update_engines()

        threading.Thread(target=self.run_listeners, daemon=True).start()
        self.setup_tray()

        if self.check_first_run():
            self.show_fullscreen_intro()
        else:
            self.sounds_enabled = True # Ha nem első futás, egyből mehet a hang
            self.show_app()

    def get_sound_packs(self):
        if os.path.exists(self.col_path):
            p = [d for d in os.listdir(self.col_path) if os.path.isdir(os.path.join(self.col_path, d))]
            return p if p else ["Nincs csomag"]
        return ["Nincs keys mappa"]

    def check_first_run(self):
        if not os.path.exists(CONFIG_FILE): return True
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f).get("first_run", True)
        except: return True

    def show_fullscreen_intro(self):
        self.intro_win = tk.Toplevel(self)
        self.intro_win.overrideredirect(True)
        w, h = self.intro_win.winfo_screenwidth(), self.intro_win.winfo_screenheight()
        self.intro_win.geometry(f"{w}x{h}+0+0")
        self.intro_win.configure(bg="black")
        self.intro_win.attributes("-topmost", True)
        
        self.intro_alpha = 0.0
        self.intro_win.attributes("-alpha", self.intro_alpha)

        self.intro_win.bind("<Alt-Key-F4>", lambda e: "break")
        self.intro_win.bind("<Escape>", lambda e: "break")

        # Intro X gomb
        self.intro_x_angle = 0
        self.intro_anim_x = False
        self.intro_x_render = ctk.CTkLabel(self.intro_win, text="", cursor="hand2", bg_color="black")
        self.intro_x_render.place(relx=0.95, rely=0.05, anchor="center")
        self.update_intro_x("#444444", 0)

        self.intro_x_render.bind("<Enter>", self.start_intro_x_rot)
        self.intro_x_render.bind("<Leave>", self.reset_intro_x_rot)
        
        # JAVÍTÁS: Itt rányomva az X-re KILÉP a programból, nem menti a FirstRun-t!
        self.intro_x_render.bind("<Button-1>", lambda e: self.quit_app())

        welcome = "Üdvözöllek a SoundsYeah-ben" if self.is_hu else "Welcome to SoundsYeah"
        btn_txt = "Kezdés" if self.is_hu else "Get Started"

        try:
            pil_img = Image.open(self.icon_path)
            logo_ctk = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(220, 220))
            logo_lbl = ctk.CTkLabel(self.intro_win, image=logo_ctk, text="", bg_color="black")
            logo_lbl.place(relx=0.5, rely=0.35, anchor="center")
        except: pass

        ctk.CTkLabel(self.intro_win, text=welcome, font=("Segoe UI Semibold", 42), 
                     text_color="white", bg_color="black").place(relx=0.5, rely=0.55, anchor="center")

        # A "Kezdés" gomb aktiválja a hangokat és menti az állapotot
        ctk.CTkButton(self.intro_win, text=btn_txt, font=("Segoe UI", 20, "bold"),
                      fg_color="#1f538d", hover_color="#2a6dbd", width=250, height=60, corner_radius=30,
                      command=self.finish_intro).place(relx=0.5, rely=0.72, anchor="center")

        self.fade_in_intro()

    def fade_in_intro(self):
        if self.intro_alpha < 0.9:
            self.intro_alpha += 0.05
            self.intro_win.attributes("-alpha", self.intro_alpha)
            self.intro_win.after(20, self.fade_in_intro)

    def finish_intro(self):
        self.sounds_enabled = True # Mostantól vannak hangok
        self.save_settings(first_run_done=True) # Elmentjük, hogy kész
        self.intro_win.destroy()
        self.show_app()

    def update_intro_x(self, color, angle):
        img = Image.new("RGBA", (200, 200), (0,0,0,0))
        d = ImageDraw.Draw(img)
        d.line([50, 50, 150, 150], fill=color, width=15)
        d.line([50, 150, 150, 50], fill=color, width=15)
        rotated = img.rotate(angle, resample=Image.BICUBIC)
        ctk_img = ctk.CTkImage(light_image=rotated, dark_image=rotated, size=(30, 30))
        self.intro_x_render.configure(image=ctk_img)

    def start_intro_x_rot(self, e):
        self.intro_anim_x = True; self.intro_x_angle = 0; self.animate_intro_x()

    def reset_intro_x_rot(self, e):
        self.intro_anim_x = False; self.update_intro_x("#444444", 0)

    def animate_intro_x(self):
        if self.intro_anim_x:
            if self.intro_x_angle < 360:
                self.intro_x_angle += 15
                self.update_intro_x("#FF3333", self.intro_x_angle)
                self.intro_win.after(10, self.animate_intro_x)
            else: self.update_intro_x("#FF3333", 0)

    def save_settings(self, first_run_done=False):
        try:
            # Ha az intro végén hívjuk, False lesz a first_run
            data = {"mouse": self.folders[self.m_idx], "kbd": self.folders[self.k_idx], 
                    "volume": self.current_volume, "first_run": not first_run_done}
            with open(CONFIG_FILE, "w") as f: json.dump(data, f)
            self.initial_m_idx, self.initial_k_idx = self.m_idx, self.k_idx
        except: pass

    # --- LISTENER HANGOKKAL ---
    def run_listeners(self):
        def on_press(key):
            if self.sounds_enabled and key not in self.pressed_keys:
                self.pressed_keys.add(key)
                self.play_random(self.kbd_sounds)
        def on_release(key):
            if key in self.pressed_keys: self.pressed_keys.remove(key)
        def on_click(x, y, button, pressed):
            if self.sounds_enabled and pressed:
                self.play_random(self.mouse_sounds)
        with keyboard.Listener(on_press=on_press, on_release=on_release) as kl, mouse.Listener(on_click=on_click) as ml:
            kl.join(); ml.join()

    # --- TOVÁBBI UI ÉS RENDSZER ---
    def setup_ui(self):
        self.card = ctk.CTkFrame(self, fg_color="#121212", corner_radius=45)
        self.card.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.9)
        self.x_angle, self.is_animating_x = 0, False
        self.x_render = ctk.CTkLabel(self.card, text="", cursor="hand2")
        self.x_render.place(relx=0.88, rely=0.08, anchor="center")
        self.update_x_image("#444444", 0)
        self.x_render.bind("<Enter>", self.start_x_rotation)
        self.x_render.bind("<Leave>", self.reset_x_rotation)
        self.x_render.bind("<Button-1>", lambda e: self.handle_close())
        ctk.CTkLabel(self.card, text="SoundsYeah", font=("Segoe UI Light", 44), text_color="white").pack(pady=(40, 20))
        def create_btn(txt, cmd):
            btn = ctk.CTkButton(self.card, text="", fg_color="#1A1A1A", hover_color="#222", corner_radius=25, height=75, width=330, command=cmd)
            btn.pack(pady=10)
            ctk.CTkLabel(btn, text=txt.upper(), font=("Segoe UI", 9, "bold"), text_color="#444").place(relx=0.5, rely=0.3, anchor="center")
            lbl = ctk.CTkLabel(btn, text="", font=("Segoe UI", 13, "bold"), text_color="#EEE")
            lbl.place(relx=0.5, rely=0.65, anchor="center")
            return lbl
        self.m_val = create_btn("Egér Hangcsomag", self.next_mouse)
        self.k_val = create_btn("Billentyűzet Hangcsomag", self.next_kbd)
        ctk.CTkLabel(self.card, text="HANGERŐ", font=("Segoe UI", 9, "bold"), text_color="#444").pack(pady=(15, 0))
        self.vol_slider = ctk.CTkSlider(self.card, from_=0, to=1, width=300, height=20, fg_color="#1A1A1A", progress_color="#333", button_color="#555", command=self.set_volume)
        self.vol_slider.pack(pady=(5, 15))
        self.typebox = ctk.CTkEntry(self.card, placeholder_text="Gépelj ide teszteléshez...", fg_color="#0A0A0A", text_color="white", height=55, width=330, corner_radius=25, border_width=0, justify="center")
        self.typebox.pack(pady=20)
        self.card.bind("<ButtonPress-1>", self.start_move)
        self.card.bind("<B1-Motion>", self.do_move)

    def load_settings(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    data = json.load(f)
                    if data.get("mouse") in self.folders: self.m_idx = self.folders.index(data["mouse"])
                    if data.get("kbd") in self.folders: self.k_idx = self.folders.index(data["kbd"])
                    self.current_volume = data.get("volume", 0.5)
                    self.vol_slider.set(self.current_volume)
            except: pass
        self.initial_m_idx, self.initial_k_idx = self.m_idx, self.k_idx

    def update_x_image(self, color, angle):
        img = Image.new("RGBA", (200, 200), (0,0,0,0))
        d = ImageDraw.Draw(img)
        d.line([50, 50, 150, 150], fill=color, width=15)
        d.line([50, 150, 150, 50], fill=color, width=15)
        rotated = img.rotate(angle, resample=Image.BICUBIC)
        ctk_img = ctk.CTkImage(light_image=rotated, dark_image=rotated, size=(25, 25))
        self.x_render.configure(image=ctk_img)

    def start_x_rotation(self, e): self.is_animating_x, self.x_angle = True, 0; self.animate_x_once()
    def reset_x_rotation(self, e): self.is_animating_x = False; self.update_x_image("#444444", 0)
    def animate_x_once(self):
        if self.is_animating_x:
            if self.x_angle < 360:
                self.x_angle += 15; self.update_x_image("#FF3333", self.x_angle); self.after(10, self.animate_x_once)
            else: self.update_x_image("#FF3333", 0)

    def handle_close(self):
        if self.m_idx != self.initial_m_idx or self.k_idx != self.initial_k_idx: self.show_exit_dialog()
        else: self.withdraw()

    def show_exit_dialog(self):
        dialog = ctk.CTkToplevel(self)
        dialog.geometry("340x180"); dialog.overrideredirect(True); dialog.attributes("-topmost", True)
        self.update_idletasks()
        x = self.winfo_x() + 90; y = self.winfo_y() + 220
        dialog.geometry(f"+{int(x)}+{int(y)}")
        frame = ctk.CTkFrame(dialog, fg_color="#1A1A1A", corner_radius=30, border_width=2, border_color="#333")
        frame.pack(fill="both", expand=True)
        msg = "Biztos menteni szeretnéd?" if self.is_hu else "Save changes?"
        ctk.CTkLabel(frame, text=msg, font=("Segoe UI", 16), text_color="white").pack(pady=(30, 20))
        btn_f = ctk.CTkFrame(frame, fg_color="transparent"); btn_f.pack(pady=10)
        y_t, c_t, n_t = ("Igen", "Mégsem", "Nincs") if self.is_hu else ("Yes", "Cancel", "No")
        ctk.CTkButton(btn_f, text=y_t, width=80, fg_color="#2E7D32", command=lambda: [self.save_settings(), self.withdraw(), dialog.destroy()]).pack(side="left", padx=5)
        ctk.CTkButton(btn_f, text=c_t, width=80, fg_color="#444", command=dialog.destroy).pack(side="left", padx=5)
        ctk.CTkButton(btn_f, text=n_t, width=80, fg_color="#C62828", command=lambda: [self.discard_changes(), dialog.destroy()]).pack(side="left", padx=5)

    def set_volume(self, val):
        self.current_volume = float(val)
        for s in self.mouse_sounds + self.kbd_sounds: s.set_volume(self.current_volume)
    def next_mouse(self): self.m_idx = (self.m_idx + 1) % len(self.folders); self.update_engines()
    def next_kbd(self): self.k_idx = (self.k_idx + 1) % len(self.folders); self.update_engines()
    def update_engines(self):
        self.m_val.configure(text=self.folders[self.m_idx])
        self.k_val.configure(text=self.folders[self.k_idx])
        self.mouse_sounds = self.load_wavs(self.folders[self.m_idx])
        self.kbd_sounds = self.load_wavs(self.folders[self.k_idx])
    def load_wavs(self, folder):
        path, sounds = os.path.join(self.col_path, folder), []
        if os.path.exists(path):
            for f in os.listdir(path):
                if f.endswith((".wav", ".ogg")):
                    try:
                        s = pygame.mixer.Sound(os.path.join(path, f))
                        s.set_volume(self.current_volume); sounds.append(s)
                    except: pass
        return sounds
    def discard_changes(self):
        self.m_idx, self.k_idx = self.initial_m_idx, self.initial_k_idx
        self.update_engines(); self.withdraw()
    def play_random(self, s_list):
        if s_list: random.choice(s_list).play()
    def setup_tray(self):
        try:
            img = Image.open(self.icon_path) if os.path.exists(self.icon_path) else Image.new('RGB', (64, 64), (30,30,30))
            l_p, l_e = ('Beállítások', 'Kilépés') if self.is_hu else ('Settings', 'Exit')
            menu = pystray.Menu(item(l_p, self.show_app, default=True), item(l_e, self.quit_app))
            self.tray = pystray.Icon("SoundsYeah", img, "SoundsYeah", menu)
            threading.Thread(target=self.tray.run, daemon=True).start()
        except: pass
    def show_app(self, icon=None, item=None): self.deiconify(); self.lift(); self.focus_force()
    def quit_app(self, icon=None, item=None):
        if hasattr(self, 'tray'): self.tray.stop()
        pygame.mixer.quit(); self.destroy(); os._exit(0)
    def start_move(self, e): self.x, self.y = e.x, e.y
    def do_move(self, e): self.geometry(f"+{self.winfo_x()+(e.x-self.x)}+{self.winfo_y()+(e.y-self.y)}")

if __name__ == "__main__":
    app = CreamyApp()
    app.mainloop()