[Setup]
AppName=SoundsYeah
AppVersion=2.0.2
DefaultDirName={autopf}\SoundsYeah
DefaultGroupName=SoundsYeah
UninstallDisplayIcon={app}\installer.ico
Compression=lzma
SolidCompression=yes
LanguageDetectionMethod=locale
OutputDir=.\Output
OutputBaseFilename=SoundsYeah_2.0.2_Installer
SetupIconFile=installer.ico

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "hungarian"; MessagesFile: "compiler:Languages\Hungarian.isl"

[Files]
Source: "output\SoundsYeah.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "keys\*"; DestDir: "{app}\keys"; Flags: ignoreversion recursesubdirs
Source: "installer.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\SoundsYeah"; Filename: "{app}\SoundsYeah.exe"; IconFilename: "{app}\installer.ico"
Name: "{autodesktop}\SoundsYeah"; Filename: "{app}\SoundsYeah.exe"; Tasks: desktopicon; IconFilename: "{app}\installer.ico"

; --- EZ A RÉSZ HIÁNYZOTT A KÉPEDRŐL ---
[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Run]
Filename: "{app}\SoundsYeah.exe"; Description: "{cm:LaunchProgram,SoundsYeah}"; Flags: nowait postinstall skipifsilent