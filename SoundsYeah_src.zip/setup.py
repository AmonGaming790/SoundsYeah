import sys
from cx_Freeze import setup, Executable

# Itt add meg a fájlokat és mappákat, amik kellenek a futáshoz
build_exe_options = {
    "packages": ["os", "pygame", "customtkinter", "pynput", "PIL", "pystray"],
    "include_files": [
        "icon.png", 
        "keys/",      # Nagyon fontos: a hangokat tartalmazó mappa!
    ],
}

# Win32GUI biztosítja, hogy ne nyíljon meg a háttérben egy fekete konzol ablak
base = None
if sys.platform == "win32":
    base = "Win32GUI"
# Parancsikon beállítások
shortcut_table = [
    ("DesktopShortcut",        # Shortcut
     "DesktopFolder",         # Directory_
     "SoundsYeah",            # Name
     "TARGETDIR",             # Component_
     "[TARGETDIR]SoundsYeah.exe",# Target
     None,                    # Arguments
     None,                    # Description
     None,                    # Hotkey
     None,                    # Icon
     None,                    # IconIndex
     None,                    # ShowCmd
     "TARGETDIR",             # WkDir
     )
]

msi_data = {"Shortcut": shortcut_table}

setup(
    name="SoundsYeah",
    version="2.0.1",
    description="System-wide mechanical keyboard and mouse sounds",
    options={
        "build_exe": build_exe_options,
        "bdist_msi": {"data": msi_data}  # <--- EZT KELL HOZZÁADNI!
    },
    executables=[
        Executable(
            "creamy.py", 
            base=base, 
            icon="icon.ico", # Ha nincs .ico-d, ezt törölheted vagy csinálj egyet!
            target_name="SoundsYeah.exe"
        )
    ],
)