import os
import sys
import random
import pygame
import threading
import ctypes
import json
import customtkinter as ctk
from pynput import keyboard, mouse
from PIL import Image, ImageDraw
import pystray
from pystray import MenuItem as item

# --- ÚTVONAL KEZELÉS EXE-HEZ ---
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# A config.json mindig az EXE mellett legyen, ne az ideiglenes mappában
if getattr(sys, 'frozen', False):
    base_dir = os.path.dirname(sys.executable)
else:
    base_dir = os.path.dirname(os.path.abspath(__file__))

CONFIG_FILE = os.path.join(base_dir, "config.json")

try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('amongaming.soundsyeah.v9')
except: pass

pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.init()

class CreamyApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("SoundsYeah")
        self.icon_path = resource_path("icon.png")
        self.withdraw() 

        self.overrideredirect(True)
        self.geometry("520x620")
        self.attributes("-topmost", True)
        self.config(bg='#242424') 
        self.attributes("-transparentcolor", "#242424")

        self.col_path = resource_path('keys')
        self.folders = self.get_sound_packs()
        
        # Állapotok
        self.m_idx, self.k_idx = 0, 0
        self.initial_m_idx, self.initial_k_idx = 0, 0 
        self.current_volume = 0.5
        self.pressed_keys = set()

        self.setup_ui()
        self.load_settings() 
        self.update_engines()

        threading.Thread(target=self.run_listeners, daemon=True).start()
        self.setup_tray()

    def get_sound_packs(self):
        if os.path.exists(self.col_path):
            p = [d for d in os.listdir(self.col_path) if os.path.isdir(os.path.join(self.col_path, d))]
            return p if p else ["Nincs csomag"]
        return ["Nincs keys mappa"]

    def load_settings(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    data = json.load(f)
                    if data.get("mouse") in self.folders: 
                        self.m_idx = self.folders.index(data["mouse"])
                    if data.get("kbd") in self.folders: 
                        self.k_idx = self.folders.index(data["kbd"])
            except: pass
        self.initial_m_idx = self.m_idx
        self.initial_k_idx = self.k_idx

    def save_settings(self):
        try:
            with open(CONFIG_FILE, "w") as f:
                json.dump({"mouse": self.folders[self.m_idx], "kbd": self.folders[self.k_idx]}, f)
            self.initial_m_idx = self.m_idx
            self.initial_k_idx = self.k_idx
        except: pass

    def discard_changes(self):
        """Visszaállítja a hangokat az utolsó mentett állapotra."""
        self.m_idx = self.initial_m_idx
        self.k_idx = self.initial_k_idx
        self.update_engines()
        self.withdraw()

    def setup_ui(self):
        self.card = ctk.CTkFrame(self, fg_color="#121212", corner_radius=45)
        self.card.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.9, relheight=0.9)

        self.x_angle = 0
        self.is_hovering_x = False
        self.x_render = ctk.CTkLabel(self.card, text="", cursor="hand2")
        self.x_render.place(relx=0.88, rely=0.08, anchor="center")
        self.update_x_image("#444444", 0)
        
        self.x_render.bind("<Enter>", self.start_x_anon)
        self.x_render.bind("<Leave>", self.stop_x_anon)
        self.x_render.bind("<Button-1>", lambda e: self.handle_close())

        ctk.CTkLabel(self.card, text="SoundsYeah", font=("Segoe UI Light", 44), text_color="white").pack(pady=(40, 20))

        def create_btn(txt, cmd):
            btn = ctk.CTkButton(self.card, text="", fg_color="#1A1A1A", hover_color="#222", corner_radius=25, height=75, width=330, command=cmd)
            btn.pack(pady=10)
            ctk.CTkLabel(btn, text=txt.upper(), font=("Segoe UI", 9, "bold"), text_color="#444").place(relx=0.5, rely=0.3, anchor="center")
            lbl = ctk.CTkLabel(btn, text="", font=("Segoe UI", 13, "bold"), text_color="#EEE")
            lbl.place(relx=0.5, rely=0.65, anchor="center")
            return lbl

        self.m_val = create_btn("Egér Hangcsomag", self.next_mouse)
        self.k_val = create_btn("Billentyűzet Hangcsomag", self.next_kbd)
        
        ctk.CTkLabel(self.card, text="HANGERŐ", font=("Segoe UI", 9, "bold"), text_color="#444").pack(pady=(15, 0))
        self.vol_slider = ctk.CTkSlider(self.card, from_=0, to=1, width=300, height=20, fg_color="#1A1A1A", progress_color="#333", button_color="#555", command=self.set_volume)
        self.vol_slider.set(self.current_volume)
        self.vol_slider.pack(pady=(5, 15))

        self.typebox = ctk.CTkEntry(self.card, placeholder_text="Gépelj ide teszteléshez...", fg_color="#0A0A0A", text_color="white", height=55, width=330, corner_radius=25, border_width=0, justify="center")
        self.typebox.pack(pady=20)

        self.card.bind("<ButtonPress-1>", self.start_move)
        self.card.bind("<B1-Motion>", self.do_move)

    def update_x_image(self, color, angle):
        img = Image.new("RGBA", (200, 200), (0,0,0,0))
        d = ImageDraw.Draw(img)
        d.line([50, 50, 150, 150], fill=color, width=15)
        d.line([50, 150, 150, 50], fill=color, width=15)
        rotated = img.rotate(angle, resample=Image.BICUBIC)
        ctk_img = ctk.CTkImage(light_image=rotated, dark_image=rotated, size=(25, 25))
        self.x_render.configure(image=ctk_img)

    def start_x_anon(self, e):
        self.is_hovering_x = True
        self.animate_x()

    def stop_x_anon(self, e):
        self.is_hovering_x = False
        self.x_angle = 0
        self.update_x_image("#444444", 0)

    def animate_x(self):
        if self.is_hovering_x:
            self.x_angle = (self.x_angle + 8) % 360
            self.update_x_image("#FF3333", self.x_angle)
            self.after(10, self.animate_x)

    def handle_close(self):
        if self.m_idx != self.initial_m_idx or self.k_idx != self.initial_k_idx:
            self.show_exit_dialog()
        else:
            self.withdraw()

    def show_exit_dialog(self):
        dialog = ctk.CTkToplevel(self)
        dialog.geometry("340x180")
        dialog.overrideredirect(True)
        dialog.attributes("-topmost", True)
        
        self.update_idletasks()
        x = self.winfo_x() + (520 // 2) - 170
        y = self.winfo_y() + (620 // 2) - 90
        dialog.geometry(f"+{int(x)}+{int(y)}")
        
        frame = ctk.CTkFrame(dialog, fg_color="#1A1A1A", corner_radius=30, border_width=2, border_color="#333")
        frame.pack(fill="both", expand=True)
        
        ctk.CTkLabel(frame, text="Biztos menteni szeretnéd?", font=("Segoe UI", 16), text_color="white").pack(pady=(30, 20))
        
        btn_f = ctk.CTkFrame(frame, fg_color="transparent")
        btn_f.pack(pady=10)
        
        ctk.CTkButton(btn_f, text="Igen", width=80, fg_color="#2E7D32", hover_color="#1B5E20", 
                      command=lambda: [self.save_settings(), self.withdraw(), dialog.destroy()]).pack(side="left", padx=5)
        ctk.CTkButton(btn_f, text="Mégsem", width=80, fg_color="#444", hover_color="#555", 
                      command=dialog.destroy).pack(side="left", padx=5)
        ctk.CTkButton(btn_f, text="Nincs", width=80, fg_color="#C62828", hover_color="#B71C1C", 
                      command=lambda: [self.discard_changes(), dialog.destroy()]).pack(side="left", padx=5)

    def set_volume(self, val):
        self.current_volume = float(val)
        for s in self.mouse_sounds + self.kbd_sounds: s.set_volume(self.current_volume)

    def next_mouse(self):
        self.m_idx = (self.m_idx + 1) % len(self.folders)
        self.update_engines()

    def next_kbd(self):
        self.k_idx = (self.k_idx + 1) % len(self.folders)
        self.update_engines()

    def update_engines(self):
        self.m_val.configure(text=self.folders[self.m_idx])
        self.k_val.configure(text=self.folders[self.k_idx])
        self.mouse_sounds = self.load_wavs(self.folders[self.m_idx])
        self.kbd_sounds = self.load_wavs(self.folders[self.k_idx])

    def load_wavs(self, folder):
        path = os.path.join(self.col_path, folder)
        sounds = []
        if os.path.exists(path):
            for f in os.listdir(path):
                if f.endswith((".wav", ".ogg")):
                    try:
                        s = pygame.mixer.Sound(os.path.join(path, f))
                        s.set_volume(self.current_volume)
                        sounds.append(s)
                    except: pass
        return sounds

    def play_random(self, s_list):
        if s_list: random.choice(s_list).play()

    def setup_tray(self):
        try:
            img = Image.open(self.icon_path) if os.path.exists(self.icon_path) else Image.new('RGB', (64, 64), (30,30,30))
            menu = pystray.Menu(item('Beállítások', self.show_app, default=True), item('Kilépés', self.quit_app))
            self.tray = pystray.Icon("SoundsYeah", img, "SoundsYeah", menu)
            threading.Thread(target=self.tray.run, daemon=True).start()
        except: pass

    def show_app(self, icon=None, item=None):
        self.deiconify()
        self.lift()
        self.focus_force()

    def quit_app(self, icon=None, item=None):
        if hasattr(self, 'tray'): self.tray.stop()
        pygame.mixer.quit()
        self.destroy()
        os._exit(0)

    def run_listeners(self):
        def on_press(key):
            if key not in self.pressed_keys:
                self.pressed_keys.add(key)
                self.play_random(self.kbd_sounds)
        def on_release(key):
            if key in self.pressed_keys: self.pressed_keys.remove(key)
        def on_click(x, y, button, pressed):
            if pressed: self.play_random(self.mouse_sounds)

        with keyboard.Listener(on_press=on_press, on_release=on_release) as kl, mouse.Listener(on_click=on_click) as ml:
            kl.join(); ml.join()

    def start_move(self, e): self.x, self.y = e.x, e.y
    def do_move(self, e):
        self.geometry(f"+{self.winfo_x()+(e.x-self.x)}+{self.winfo_y()+(e.y-self.y)}")

if __name__ == "__main__":
    app = CreamyApp()
    app.mainloop()